# Requirements

* **Node.js** >= 4, preferably >=6
  * It uses ES2015.
* [**npm**](https://www.npmjs.com/), preferably >=5

Other dependencies are installed via npm, and do not need to be pre-installed.
